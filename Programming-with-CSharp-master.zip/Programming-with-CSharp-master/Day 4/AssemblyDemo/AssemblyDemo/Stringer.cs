﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssemblyDemo
{
        public class Stringer
        {
            public void StringerMethod()
            {
                System.Console.WriteLine("This is a line from StringerMethod.");
            }
        }
}