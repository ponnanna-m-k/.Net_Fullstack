﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LatestFeatures
{
    class EnumDemo
    {
        public enum MyEnum
        {
            chair = 10,
            table = 20,
            mouse = 30
        }
    }
}
