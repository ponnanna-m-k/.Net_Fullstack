﻿using System;

namespace StackQueue
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
