﻿using System;

namespace InheritanceDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //bcd obj = new bcd();
            //obj.funcA();

            c3 obj = new c3();
            obj.func1();
            //obj.func2();
            obj.func3();
        }
    }
}
